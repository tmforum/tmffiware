from wstore.asset_manager.resource_plugins.plugin import Plugin

class TestPlugin(Plugin):
    pass
